"""
matching_engine.py

Ranks job/internship postings for a given candidate.

Two signals are combined:
1. ATS Score        - semantic skill match between resume and job description
                       (your existing logic).
2. Preference Score  - hard filters + soft boosts derived from the user's
                       free-text preferences, parsed by
                       engine/preference_extractor.py (new in this change).

NOTE ON INTEGRATION: `fetch_resume_skills`, `fetch_open_jobs`, and
`calculate_ats_score` are placeholders standing in for whatever you already
have wired to Supabase / your ATS matcher. Delete the placeholder bodies
below and import your real implementations instead - the new pieces you
actually need to add to your existing file are:

    apply_hard_filters()
    apply_soft_ranking()
    get_ranked_jobs_for_user()   <- new single entry point used by the route

If you already have an existing `rank_jobs_for_user(user_id)`-style function,
the fastest integration is to keep it as-is for the ATS pass, then pipe its
output through `apply_hard_filters` / `apply_soft_ranking` before returning.
"""

from typing import Dict, List, Optional

from pydantic import BaseModel, Field

from engine.preference_extractor import PreferenceFilters

# ---------------------------------------------------------------------------
# Data model (replace with your real Job model / import if one exists)
# ---------------------------------------------------------------------------


class Job(BaseModel):
    id: str
    title: str
    company: str
    location: str  # e.g. "San Francisco, CA" or "Remote"
    is_remote: bool
    stipend_monthly: Optional[int] = None
    description: str
    required_skills: List[str] = Field(default_factory=list)


class JobMatch(BaseModel):
    job: Job
    ats_score: float  # 0-100, from existing resume/skill matching
    match_score: float  # ats_score after preference boosts, capped at 100
    matched_preferences: List[str] = Field(default_factory=list)  # for UI transparency


# ---------------------------------------------------------------------------
# Existing placeholders - swap these for your real implementations/imports
# ---------------------------------------------------------------------------


def fetch_resume_skills(user_id: str) -> List[str]:
    """Existing function: pulls parsed resume skills for this user from Supabase."""
    raise NotImplementedError("Wire this up to your existing Supabase query.")


def fetch_open_jobs() -> List[Job]:
    """Existing function: pulls all open job/internship postings from Supabase."""
    raise NotImplementedError("Wire this up to your existing Supabase query.")


def calculate_ats_score(resume_skills: List[str], job: Job) -> float:
    """Existing function: your current strict semantic ATS matcher, 0-100."""
    raise NotImplementedError("Replace with your existing ATS scoring logic.")


# ---------------------------------------------------------------------------
# NEW: Preference-based hard filters
# ---------------------------------------------------------------------------


def _location_matches(job: Job, preferred_locations: List[str]) -> bool:
    if not preferred_locations:
        return True  # no location preference stated -> don't filter anything out

    wants_remote = any(loc.strip().lower() == "remote" for loc in preferred_locations)
    if wants_remote and job.is_remote:
        return True

    job_location = job.location.lower()
    return any(
        loc.strip().lower() in job_location
        for loc in preferred_locations
        if loc.strip().lower() != "remote"
    )


def apply_hard_filters(jobs: List[Job], preferences: PreferenceFilters) -> List[Job]:
    """Drop any job that violates a strict, explicitly stated preference."""
    filtered: List[Job] = []

    for job in jobs:
        if not _location_matches(job, preferences.preferred_locations):
            continue

        if preferences.min_stipend_monthly is not None:
            if job.stipend_monthly is None or job.stipend_monthly < preferences.min_stipend_monthly:
                continue

        if preferences.must_have:
            haystack = f"{job.title} {job.description}".lower()
            if not all(req.lower() in haystack for req in preferences.must_have):
                continue

        filtered.append(job)

    return filtered


# ---------------------------------------------------------------------------
# NEW: Preference-based soft ranking
# ---------------------------------------------------------------------------

ROLE_KEYWORD_BOOST = 0.15  # +15% match score for a role keyword hit
LOCATION_BOOST = 0.05  # +5% extra for an exact, non-remote location hit


def apply_soft_ranking(
    jobs: List[Job],
    preferences: PreferenceFilters,
    base_scores: Dict[str, float],
) -> List[JobMatch]:
    """
    Take ATS base scores and boost them where a job aligns with soft
    (non-strict) preferences, returning fully-formed JobMatch objects.
    """
    matches: List[JobMatch] = []

    for job in jobs:
        base = base_scores.get(job.id, 0.0)
        score = base
        matched: List[str] = []

        haystack = f"{job.title} {job.description}".lower()
        if any(kw.lower() in haystack for kw in preferences.role_keywords):
            score *= 1 + ROLE_KEYWORD_BOOST
            matched.append("role_keyword")

        non_remote_locations = [
            loc for loc in preferences.preferred_locations if loc.lower() != "remote"
        ]
        if non_remote_locations and any(
            loc.lower() in job.location.lower() for loc in non_remote_locations
        ):
            score *= 1 + LOCATION_BOOST
            matched.append("preferred_location")

        matches.append(
            JobMatch(
                job=job,
                ats_score=base,
                match_score=round(min(score, 100.0), 2),
                matched_preferences=matched,
            )
        )

    return matches


# ---------------------------------------------------------------------------
# NEW: Single entry point used by the /api/recommendations/preferences route
# ---------------------------------------------------------------------------


def get_ranked_jobs_for_user(
    user_id: str, preferences: Optional[PreferenceFilters] = None
) -> List[JobMatch]:
    """
    Full pipeline: fetch resume + jobs, hard-filter by preferences, score
    with the existing ATS matcher, soft-boost by preferences, sort, return.
    """
    preferences = preferences or PreferenceFilters()

    resume_skills = fetch_resume_skills(user_id)
    all_jobs = fetch_open_jobs()

    eligible_jobs = apply_hard_filters(all_jobs, preferences)

    base_scores = {job.id: calculate_ats_score(resume_skills, job) for job in eligible_jobs}

    ranked = apply_soft_ranking(eligible_jobs, preferences, base_scores)
    ranked.sort(key=lambda m: m.match_score, reverse=True)

    return ranked
